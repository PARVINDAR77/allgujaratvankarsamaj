import {
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
  ConflictException,
} from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import { User, Role, Status, Gender, ProfileStatus, VerificationStatus } from "@prisma/client";
import { v4 as uuidv4 } from "uuid";
import * as bcrypt from "bcrypt";
import { normalizeGender } from "../profiles/dto/normalize-profile.helper";

export function normalizePhoneNumber(phone?: string | null): {
  isValid: boolean;
  canonical10?: string;
  variants: string[];
} {
  if (!phone || typeof phone !== "string") {
    return { isValid: false, variants: [] };
  }
  const trimmed = phone.trim();
  if (!trimmed) {
    return { isValid: false, variants: [] };
  }
  // Remove all non-digit characters
  const digitsOnly = trimmed.replace(/\D/g, "");

  if (digitsOnly.length === 10) {
    return {
      isValid: true,
      canonical10: digitsOnly,
      variants: [digitsOnly, `+91${digitsOnly}`, `91${digitsOnly}`],
    };
  }

  if (digitsOnly.length === 12 && digitsOnly.startsWith("91")) {
    const tenDigit = digitsOnly.slice(2);
    return {
      isValid: true,
      canonical10: tenDigit,
      variants: [tenDigit, `+91${tenDigit}`, `91${tenDigit}`],
    };
  }

  return { isValid: false, variants: [] };
}

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name);

  constructor(private readonly prisma: PrismaService) {}

  async findByEmail(email?: string): Promise<User | null> {
    if (!email) return null;
    const normalized = email.toLowerCase().trim();
    return await this.prisma.user.findUnique({
      where: { email: normalized },
    });
  }

  async findByPhone(phone?: string): Promise<User | null> {
    const norm = normalizePhoneNumber(phone);
    if (!norm.isValid || norm.variants.length === 0) {
      return null;
    }

    const matches = await this.prisma.user.findMany({
      where: {
        phone: { in: norm.variants },
      },
      take: 2,
    });

    if (matches.length === 0) {
      return null;
    }

    if (matches.length > 1) {
      this.logger.error(
        `Ambiguous phone lookup detected for input: "${phone}". Multiple user records match variants: [${norm.variants.join(", ")}]. Failing safely.`,
      );
      return null;
    }

    return matches[0];
  }

  async findById(id: string): Promise<User | null> {
    return await this.prisma.user.findUnique({
      where: { id },
    });
  }

  async createUser(data: {
    email?: string;
    phone?: string;
    name?: string;
    gender?: string;
    passwordHash: string;
    role?: Role;
    status?: Status;
  }): Promise<User> {
    const normalizedEmail =
      data.email?.toLowerCase().trim() || `${uuidv4()}@vankar.org`;
    const resolvedGender = normalizeGender(data.gender);
    try {
      const user = await this.prisma.user.create({
        data: {
          email: normalizedEmail,
          phone: data.phone,
          name: data.name,
          gender: resolvedGender,
          passwordHash: data.passwordHash,
          role: data.role || Role.USER,
          status: data.status || Status.ACTIVE,
        },
      });
      return user;
    } catch (err: any) {
      if (err.code === "P2002") {
        throw new ConflictException(
          "આ ઈમેઈલ અથવા મોબાઇલ નંબર પહેલેથી જ નોંધાયેલ છે (Email or mobile number is already registered)",
        );
      }
      throw err;
    }
  }

  // --- Admin Endpoints ---

  async getAllUsersForAdmin() {
    try {
      const users = await this.prisma.user.findMany({
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          status: true,
          role: true,
          createdAt: true,
          profile: {
            select: {
              firstName: true,
              lastName: true,
              city: true,
              nativePlace: true,
            },
          },
        },
      });
      return users.map((u) => ({
        id: u.id,
        name:
          u.name ||
          (u.profile?.firstName
            ? `${u.profile.firstName} ${u.profile.lastName || ""}`.trim()
            : u.email || "Member"),
        email: u.email || "",
        phone: u.phone || "9876543210",
        pargana: u.profile?.city || u.profile?.nativePlace || "35 Pargana",
        status: u.status,
        role: u.role,
        createdAt: u.createdAt,
      }));
    } catch (err) {
      this.logger.error("Failed to query admin users with profiles, falling back to basic users", err);
      const basicUsers = await this.prisma.user.findMany({
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          name: true,
          email: true,
          phone: true,
          status: true,
          role: true,
          createdAt: true,
        },
      });
      return basicUsers.map((u) => ({
        id: u.id,
        name: u.name || u.email || "Member",
        email: u.email || "",
        phone: u.phone || "9876543210",
        pargana: "35 Pargana",
        status: u.status,
        role: u.role,
        createdAt: u.createdAt,
      }));
    }
  }

  async updateUserStatusAdmin(
    userId: string,
    adminId: string,
    status: Status,
    ipAddress?: string,
  ) {
    if (!Object.values(Status).includes(status)) {
      throw new BadRequestException("Invalid status");
    }

    return this.prisma.$transaction(async (tx) => {
      const user = await tx.user.findUnique({ where: { id: userId } });
      if (!user) throw new NotFoundException("User not found");

      const updatedUser = await tx.user.update({
        where: { id: userId },
        data: { status },
      });

      await tx.adminAuditLog.create({
        data: {
          adminId,
          action: "UPDATE_USER_STATUS",
          entityId: userId,
          entityType: "User",
          oldValue: JSON.stringify({ status: user.status }),
          newValue: JSON.stringify({ status: updatedUser.status }),
          ipAddress: ipAddress || null,
        },
      });

      return {
        id: updatedUser.id,
        status: updatedUser.status,
      };
    });
  }

  async updateUserRoleAdmin(
    userId: string,
    adminId: string,
    role: Role,
    ipAddress?: string,
  ) {
    if (!Object.values(Role).includes(role)) {
      throw new BadRequestException("Invalid role");
    }

    return this.prisma.$transaction(async (tx) => {
      const user = await tx.user.findUnique({ where: { id: userId } });
      if (!user) throw new NotFoundException("User not found");

      const updatedUser = await tx.user.update({
        where: { id: userId },
        data: { role },
      });

      await tx.adminAuditLog.create({
        data: {
          adminId,
          action: "UPDATE_USER_ROLE",
          entityId: userId,
          entityType: "User",
          oldValue: JSON.stringify({ role: user.role }),
          newValue: JSON.stringify({ role: updatedUser.role }),
          ipAddress: ipAddress || null,
        },
      });

      return {
        id: updatedUser.id,
        role: updatedUser.role,
      };
    });
  }

  async getAllProfilesForAdmin() {
    try {
      const profiles = await this.prisma.matrimonialProfile.findMany({
        orderBy: { createdAt: "desc" },
        select: {
          id: true,
          userId: true,
          firstName: true,
          lastName: true,
          dateOfBirth: true,
          gender: true,
          nativePlace: true,
          city: true,
          education: true,
          occupation: true,
          photoUrl: true,
          photos: true,
          status: true,
          isVerified: true,
          isFeatured: true,
          createdAt: true,
          user: {
            select: {
              email: true,
              phone: true,
            },
          },
          verificationRequests: {
            orderBy: { createdAt: "desc" },
            take: 1,
            select: {
              id: true,
              documentType: true,
              documentUrl: true,
              documentBackUrl: true,
              status: true,
              createdAt: true,
            },
          },
        },
      });
      return profiles.map((p) => {
        let parsedPhotos: string[] = [];
        if (p.photos) {
          try {
            parsedPhotos = JSON.parse(p.photos);
          } catch (_) {
            parsedPhotos = [p.photos];
          }
        } else if (p.photoUrl) {
          parsedPhotos = [p.photoUrl];
        }

        return {
          id: p.id,
          userId: p.userId,
          name: `${p.firstName} ${p.lastName || ""}`.trim(),
          age: p.dateOfBirth
            ? new Date().getFullYear() - new Date(p.dateOfBirth).getFullYear()
            : 26,
          gender: p.gender,
          pargana: p.nativePlace || "35 Pargana",
          city: p.city || "Ahmedabad",
          education: p.education || "Graduate",
          occupation: p.occupation || "Service",
          photoUrl: p.photoUrl,
          photos: parsedPhotos,
          verification:
            p.verificationRequests && p.verificationRequests[0]
              ? p.verificationRequests[0]
              : null,
          user: p.user,
          status: p.status || "PENDING",
          isVerified: p.isVerified,
          isFeatured: p.isFeatured,
          createdAt: p.createdAt,
        };
      });
    } catch (err) {
      this.logger.error("Failed to query admin matrimonial profiles", err);
      return [];
    }
  }

  async updateProfileStatusAdmin(
    profileId: string,
    adminId: string,
    status: string,
    ipAddress?: string,
  ) {
    return this.prisma.$transaction(async (tx) => {
      const profile = await tx.matrimonialProfile.findUnique({
        where: { id: profileId },
      });
      if (!profile) throw new NotFoundException("Profile not found");

      const isApproved = status === "APPROVED" || status === "ACTIVE";
      const profileStatus = isApproved ? ProfileStatus.APPROVED : ProfileStatus.REJECTED;

      const updatedProfile = await tx.matrimonialProfile.update({
        where: { id: profileId },
        data: {
          status: profileStatus,
          isVerified: isApproved,
        },
      });

      // Also update any pending verification requests for this profile
      await tx.verificationRequest.updateMany({
        where: { profileId, status: VerificationStatus.PENDING },
        data: {
          status: isApproved ? VerificationStatus.VERIFIED : VerificationStatus.REJECTED,
        },
      });

      // Also update any government employment status for this profile
      await tx.governmentEmployment.updateMany({
        where: { profileId },
        data: {
          verificationStatus: isApproved ? "VERIFIED" : "REJECTED",
          isActive: isApproved,
        },
      });

      await tx.adminAuditLog.create({
        data: {
          adminId,
          action: "UPDATE_PROFILE_STATUS",
          entityId: profileId,
          entityType: "MatrimonialProfile",
          oldValue: JSON.stringify({ status: profile.status, isVerified: profile.isVerified }),
          newValue: JSON.stringify({ status: updatedProfile.status, isVerified: updatedProfile.isVerified }),
          ipAddress: ipAddress || null,
        },
      });

      return { id: profileId, status: updatedProfile.status, isVerified: updatedProfile.isVerified };
    });
  }

  async toggleProfileFeaturedAdmin(
    profileId: string,
    adminId: string,
    isFeatured: boolean,
    ipAddress?: string,
  ) {
    return this.prisma.$transaction(async (tx) => {
      const profile = await tx.matrimonialProfile.findUnique({
        where: { id: profileId },
      });
      if (!profile) throw new NotFoundException("Profile not found");

      const updatedProfile = await tx.matrimonialProfile.update({
        where: { id: profileId },
        data: { isFeatured },
      });

      await tx.governmentEmployment.updateMany({
        where: { profileId },
        data: { isFeatured },
      });

      await tx.adminAuditLog.create({
        data: {
          adminId,
          action: "TOGGLE_PROFILE_FEATURED",
          entityId: profileId,
          entityType: "MatrimonialProfile",
          oldValue: JSON.stringify({ isFeatured: profile.isFeatured }),
          newValue: JSON.stringify({ isFeatured: updatedProfile.isFeatured }),
          ipAddress: ipAddress || null,
        },
      });

      return { id: profileId, isFeatured: updatedProfile.isFeatured };
    });
  }
}
