import {
  ConflictException,
  Injectable,
  UnauthorizedException,
} from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { JwtService } from "@nestjs/jwt";
import * as bcrypt from "bcrypt";
import { ProfileStatus } from "@prisma/client";
import { PrismaService } from "../prisma/prisma.service";
import { UsersService } from "../users/users.service";
import { LoginDto } from "./dto/login.dto";
import { RegisterDto } from "./dto/register.dto";

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly prisma: PrismaService,
  ) {}

  async register(dto: RegisterDto) {
    // Check for existing user by email or phone - Candidate can use their email only ONE time
    if (dto.email) {
      const cleanEmail = dto.email.trim().toLowerCase();
      const existingByEmail = await this.usersService.findByEmail(cleanEmail);
      if (existingByEmail) {
        throw new ConflictException(
          "આ ઈમેઈલ સરનામું પહેલેથી જ વપરાયેલ છે. ઉમેદવાર માત્ર એક જ વાર ઈમેઈલનો ઉપયોગ કરી શકે છે. (This email is already registered. Candidates can use their email only once.)",
        );
      }

      // Check if email was used in any candidate profile
      const existingProfileEmail = await this.prisma.matrimonialProfile.findFirst({
        where: { contactEmail: cleanEmail },
      });
      if (existingProfileEmail) {
        throw new ConflictException(
          "આ ઈમેઈલ અન્ય ઉમેદવાર દ્વારા પહેલેથી જ વપરાયેલ છે. ઉમેદવાર માત્ર એક જ વાર ઈમેઈલનો ઉપયોગ કરી શકે છે. (This email is already in use by another candidate. Candidates can use their email only once.)",
        );
      }
    }
    if (dto.phone) {
      const cleanPhone = dto.phone.trim();
      const existingByPhone = await this.usersService.findByPhone(cleanPhone);
      if (existingByPhone) {
        throw new ConflictException(
          "આ મોબાઇલ નંબર પહેલેથી જ નોંધાયેલ છે. (This mobile number is already registered.)",
        );
      }
    }

    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(dto.password, saltRounds);

    const user = await this.usersService.createUser({
      email: dto.email,
      phone: dto.phone,
      name: dto.name,
      gender: dto.gender,
      passwordHash,
    });

    const { passwordHash: _, ...safeUser } = user;
    return {
      ...safeUser,
      isVerified: false,
      hasProfile: false,
      profileStatus: "NOT_CREATED",
    };
  }

  async login(dto: LoginDto) {
    let user = dto.phone
      ? await this.usersService.findByPhone(dto.phone)
      : null;
    if (!user && dto.email) {
      user = await this.usersService.findByEmail(dto.email);
    }

    if (!user) {
      throw new UnauthorizedException(
        "અમાન્ય ઓળખપત્ર (Invalid email/phone or password)",
      );
    }

    const isPasswordValid = await bcrypt.compare(
      dto.password,
      user.passwordHash,
    );
    if (!isPasswordValid) {
      throw new UnauthorizedException(
        "અમાન્ય ઓળખપત્ર (Invalid email/phone or password)",
      );
    }

    if (user.status !== "ACTIVE") {
      throw new UnauthorizedException(
        "આ એકાઉન્ટ નિષ્ક્રિય છે (Account is deactivated)",
      );
    }

    const profile = await this.prisma.matrimonialProfile.findUnique({
      where: { userId: user.id },
    });

    const isStub =
      profile &&
      profile.firstName === "User" &&
      profile.lastName === "Member" &&
      !profile.religion &&
      !profile.education &&
      !profile.caste;

    const hasProfile = profile !== null && !isStub;

    const isVerified =
      hasProfile &&
      profile?.isVerified === true &&
      profile?.status === ProfileStatus.APPROVED;

    const payload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      isVerified,
      hasProfile,
    };

    const expiresIn = this.configService.get<string>("JWT_EXPIRES_IN", "1d");
    const accessToken = this.jwtService.sign(payload);

    const { passwordHash: _, ...safeUser } = user;

    return {
      accessToken,
      user: {
        ...safeUser,
        isVerified,
        hasProfile,
        profileStatus: profile?.status ?? "PENDING",
      },
      tokenType: "Bearer",
      expiresIn,
    };
  }
}
