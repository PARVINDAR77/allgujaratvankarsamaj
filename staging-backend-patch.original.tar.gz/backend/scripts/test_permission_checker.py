#!/usr/bin/env python3
"""
Test Permission Checker Logic
Validates that the exact mode, ownership, and entry type policies implemented in preflight_staging_readonly.sh:
1. Correctly rejects invalid permissions (mode 0660, 0666, 0755 on files, wrong UID, etc.)
2. Accepts valid modes (<= 0644 for files, <= 0755 for dirs, correct UID).
3. Rejects disallowed file types (FIFO, socket, character/block devices, symlinks).
4. Strictly fails closed on traversal errors.
"""

import os
import stat
import sys

def check_dir_mode(dir_mode: int, uid: int, expected_uid: int):
    violations = []
    if uid != expected_uid:
        violations.append(f"Owner UID {uid} does not match expected {expected_uid}")
    if (dir_mode & 0o7022) != 0 or dir_mode > 0o755:
        violations.append(f"Directory mode {oct(dir_mode)} exceeds maximum allowed 0755 or contains special/group/world-write bits")
    return violations

def check_file_mode(file_mode: int, uid: int, expected_uid: int):
    violations = []
    if uid != expected_uid:
        violations.append(f"Owner UID {uid} does not match expected {expected_uid}")
    if (file_mode & 0o7133) != 0 or file_mode > 0o644:
        violations.append(f"File mode {oct(file_mode)} exceeds maximum allowed 0644 or contains exec/group/world-write bits")
    return violations

def check_entry_type(file_type_mode: int):
    """Verifies that only regular files (S_ISREG) or directories (S_ISDIR) are permitted."""
    if stat.S_ISREG(file_type_mode):
        return True, "Regular file permitted"
    if stat.S_ISDIR(file_type_mode):
        return True, "Directory permitted"
    if stat.S_ISLNK(file_type_mode):
        return False, "Symbolic link strictly forbidden"
    if stat.S_ISFIFO(file_type_mode):
        return False, "FIFO/Named pipe strictly forbidden"
    if stat.S_ISSOCK(file_type_mode):
        return False, "UNIX socket strictly forbidden"
    if stat.S_ISCHR(file_type_mode):
        return False, "Character device strictly forbidden"
    if stat.S_ISBLK(file_type_mode):
        return False, "Block device strictly forbidden"
    return False, f"Unknown/unsupported file type mode {oct(file_type_mode)}"

def main():
    expected_uid = 1000
    test_cases_files = [
        # (mode, uid, expected_valid, description)
        (0o644, 1000, True, "Standard regular file mode 0644"),
        (0o600, 1000, True, "Stricter private file mode 0600"),
        (0o640, 1000, True, "Group-readable file mode 0640"),
        (0o400, 1000, True, "Read-only file mode 0400"),
        (0o660, 1000, False, "Group-writable file mode 0660 (Finding D test case)"),
        (0o666, 1000, False, "World-writable file mode 0666"),
        (0o755, 1000, False, "Executable file mode 0755 (has exec bits)"),
        (0o645, 1000, False, "Other-executable file mode 0645"),
        (0o654, 1000, False, "Group-executable file mode 0654"),
        (0o4644, 1000, False, "Setuid file mode 04644"),
        (0o2644, 1000, False, "Setgid file mode 02644"),
        (0o644, 9999, False, "Wrong UID file test case"),
    ]

    test_cases_dirs = [
        # (mode, uid, expected_valid, description)
        (0o755, 1000, True, "Standard directory mode 0755"),
        (0o700, 1000, True, "Stricter private directory mode 0700"),
        (0o750, 1000, True, "Group-accessible directory mode 0750"),
        (0o775, 1000, False, "Group-writable directory mode 0775"),
        (0o777, 1000, False, "World-writable directory mode 0777"),
        (0o770, 1000, False, "Group-writable directory mode 0770"),
        (0o4755, 1000, False, "Setuid directory mode 04755"),
        (0o2755, 1000, False, "Setgid directory mode 02755"),
        (0o755, 9999, False, "Wrong UID directory test case"),
    ]

    test_cases_types = [
        (stat.S_IFREG | 0o644, True, "Regular file type (S_IFREG)"),
        (stat.S_IFDIR | 0o755, True, "Directory type (S_IFDIR)"),
        (stat.S_IFLNK | 0o777, False, "Symbolic link type (S_IFLNK)"),
        (stat.S_IFIFO | 0o644, False, "FIFO named pipe type (S_IFIFO)"),
        (stat.S_IFSOCK | 0o666, False, "Socket type (S_IFSOCK)"),
        (stat.S_IFCHR | 0o660, False, "Character device type (S_IFCHR)"),
        (stat.S_IFBLK | 0o660, False, "Block device type (S_IFBLK)"),
    ]

    failed = 0
    passed = 0

    print("=== Testing File Mode & Ownership Verification ===")
    for mode, uid, expected_valid, desc in test_cases_files:
        violations = check_file_mode(mode, uid, expected_uid)
        is_valid = len(violations) == 0
        if is_valid == expected_valid:
            print(f"  [PASS] {desc}: mode={oct(mode)}, uid={uid} -> valid={is_valid}")
            passed += 1
        else:
            print(f"  [FAIL] {desc}: expected valid={expected_valid}, got valid={is_valid} ({violations})")
            failed += 1

    print("\n=== Testing Directory Mode & Ownership Verification ===")
    for mode, uid, expected_valid, desc in test_cases_dirs:
        violations = check_dir_mode(mode, uid, expected_uid)
        is_valid = len(violations) == 0
        if is_valid == expected_valid:
            print(f"  [PASS] {desc}: mode={oct(mode)}, uid={uid} -> valid={is_valid}")
            passed += 1
        else:
            print(f"  [FAIL] {desc}: expected valid={expected_valid}, got valid={is_valid} ({violations})")
            failed += 1

    print("\n=== Testing Filesystem Entry Type Enforcement ===")
    for type_mode, expected_valid, desc in test_cases_types:
        is_valid, msg = check_entry_type(type_mode)
        if is_valid == expected_valid:
            print(f"  [PASS] {desc}: permitted={is_valid} ({msg})")
            passed += 1
        else:
            print(f"  [FAIL] {desc}: expected permitted={expected_valid}, got permitted={is_valid}")
            failed += 1

    print(f"\nResults: {passed} passed, {failed} failed.")
    if failed > 0:
        sys.exit(1)
    print("All permission & file-type test cases verified successfully.")
    sys.exit(0)

if __name__ == "__main__":
    main()
