#!/usr/bin/env python3
"""
Archive AST Structural Verifier & Content Secret Scanner
Strictly validates tar archive structure and content for All Gujarat Vankar Samaj Matrimony.

Separates:
1. Strict Canonical Path & Type Validation (Structural Verification)
2. Content Secret Scanning (Data Protection Verification)
"""

import sys
import os
import re
import tarfile

# Regex for detecting potential secrets in file contents
SECRET_CONTENT_PATTERNS = [
    (re.compile(rb"-----BEGIN\s+(?:RSA\s+)?PRIVATE\s+KEY-----"), "Private key header"),
    (re.compile(rb"-----BEGIN\s+CERTIFICATE-----"), "Certificate block"),
    (re.compile(rb"""(?:JWT_SECRET|SECRET_KEY|DATABASE_URL|MYSQL_PASSWORD)\s*=\s*['"](?![$][{A-Za-z0-9_]+[}]|mysql:\/\/[^:]+:\${)[^'"]{8,}['"]""", re.IGNORECASE), "Plaintext credential assignment"),
    (re.compile(rb"AKIA[0-9A-Z]{16}"), "AWS Access Key ID"),
    (re.compile(rb"(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36}"), "GitHub Personal Access Token"),
]

def verify_archive(archive_path: str) -> bool:
    structural_violations = []
    secret_violations = []
    seen_canonical_names = set()
    regular_files_scanned = 0

    try:
        with tarfile.open(archive_path, "r:gz") as tar:
            members = tar.getmembers()
            if len(members) == 0:
                sys.stderr.write("Archive contains 0 members (empty archive)\n")
                return False

            for m in members:
                raw_name = m.name

                # ==============================================================
                # --- PHASE 1: STRICT CANONICAL PATH & TYPE VALIDATION ---
                # ==============================================================

                # 1.1 Reject control characters and unprintable bytes
                if any(ord(c) < 32 or ord(c) == 127 for c in raw_name):
                    structural_violations.append(f"Control characters in path: {repr(raw_name)}")

                # 1.2 Reject backslashes and drive colons
                if "\\" in raw_name or ":" in raw_name:
                    structural_violations.append(f"Backslash or drive colon in path: {repr(raw_name)}")

                # 1.3 Reject leading slashes and consecutive slashes
                if raw_name.startswith("/") or "//" in raw_name:
                    structural_violations.append(f"Leading or consecutive slashes in path: {repr(raw_name)}")

                # 1.4 Strict canonical path policy: reject literal '.' or '..' segments
                if re.search(r'(^|/)\.\.?(?:/|$)', raw_name):
                    structural_violations.append(f"Literal dot or directory traversal component in path: {repr(raw_name)}")

                # 1.5 Strict root prefix: all entries must reside strictly under 'backend/'
                clean_name = raw_name.rstrip("/")
                if clean_name != "backend" and not raw_name.startswith("backend/"):
                    structural_violations.append(f"Entry does not begin with canonical 'backend/' prefix: {repr(raw_name)}")

                # 1.6 Duplicate or conflicting entry detection
                canonical_key = clean_name.lower()
                if canonical_key in seen_canonical_names:
                    structural_violations.append(f"Duplicate or case-colliding archive entry: {repr(raw_name)}")
                seen_canonical_names.add(canonical_key)

                # 1.7 Prohibited entry types: only regular files and directories allowed
                if not (m.isfile() or m.isdir()):
                    structural_violations.append(f"Disallowed entry type ({m.type} - not regular file or dir): {repr(raw_name)}")

                # 1.8 Segment-by-segment canonical analysis
                parts = clean_name.split("/")
                for part in parts:
                    if part == "" or part == "." or part == "..":
                        structural_violations.append(f"Empty or dot segment in parsed path: {repr(raw_name)}")
                    if part.startswith(".") and part != ".prisma":
                        if part == ".env" or part.startswith(".env.") or part.endswith(".env"):
                            structural_violations.append(f"Sensitive environment filename: {repr(raw_name)}")

                # ==============================================================
                # --- PHASE 2: CONTENT SECRET SCANNING (INDEPENDENT AUDIT) ---
                # ==============================================================
                if m.isfile():
                    regular_files_scanned += 1
                    base_lower = os.path.basename(clean_name).lower()

                    # Prohibit key/certificate file extensions
                    if base_lower.endswith((".key", ".pem", ".pfx", ".p12", ".pkcs12", ".id_rsa")):
                        secret_violations.append(f"Prohibited cryptographic key file: {repr(raw_name)}")

                    # Inspect file contents for plaintext credentials and keys (up to 5MB per file)
                    if m.size > 0 and m.size < 5 * 1024 * 1024:
                        f = tar.extractfile(m)
                        if f is not None:
                            content = f.read()
                            lines = content.splitlines()
                            for line in lines:
                                stripped = line.strip()
                                # Skip comments, sed regex redactions, and log examples
                                if stripped.startswith(b"#") or stripped.startswith(b"//") or b"REDACTED" in stripped or b"sed " in stripped:
                                    continue
                                for pattern, desc in SECRET_CONTENT_PATTERNS:
                                    if pattern.search(line):
                                        secret_violations.append(f"Secret detected in file content ({desc}): {repr(raw_name)}")
                                        break

            # Report results separately
            if structural_violations or secret_violations:
                sys.stderr.write(f"Archive validation FAILED:\n")
                if structural_violations:
                    sys.stderr.write(f"  Structural Violations ({len(structural_violations)}):\n")
                    for v in structural_violations[:10]:
                        sys.stderr.write(f"    - {v}\n")
                if secret_violations:
                    sys.stderr.write(f"  Secret/Credential Violations ({len(secret_violations)}):\n")
                    for v in secret_violations[:10]:
                        sys.stderr.write(f"    - {v}\n")
                return False

            print(f"SUCCESS: Archive Structural & Content Verification Complete:")
            print(f"  - Structural Validation: PASSED ({len(members)} canonical entries, 0 traversals, 0 backslashes, 0 duplicates, 0 symlinks)")
            print(f"  - Content Secret Scanning: PASSED ({regular_files_scanned} regular files inspected, 0 private keys, 0 plaintext credentials found)")
            return True

    except Exception as e:
        sys.stderr.write(f"Archive parsing exception: {e}\n")
        return False

def main():
    archive_path = sys.argv[1] if len(sys.argv) > 1 else "staging-backend-patch.tar.gz"
    success = verify_archive(archive_path)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
